// Types
export interface Course {
  id: string;
  title: string;
  level: string;
  description: string;
  content: string;
  attachments: { name: string; url: string }[];
  createdAt: string;
  updatedAt: string;
}

export interface Question {
  id: string;
  text: string;
  type: 'qcm' | 'text' | 'truefalse';
  options?: string[];
  correctAnswer: string;
  points: number;
}

export interface Evaluation {
  id: string;
  title: string;
  level: string;
  courseId?: string;
  description: string;
  questions: Question[];
  duration: number; // minutes
  isActive: boolean;
  createdAt: string;
}

export interface StudentResult {
  id: string;
  evaluationId: string;
  studentName: string;
  studentClass: string;
  answers: { questionId: string; answer: string; isCorrect: boolean; points: number }[];
  totalScore: number;
  maxScore: number;
  percentage: number;
  submittedAt: string;
}

// Helper
const generateId = () => Math.random().toString(36).substring(2, 15) + Date.now().toString(36);

// Courses
export const getCourses = (): Course[] => {
  const data = localStorage.getItem('techno_courses');
  return data ? JSON.parse(data) : [];
};

export const saveCourse = (course: Omit<Course, 'id' | 'createdAt' | 'updatedAt'>): Course => {
  const courses = getCourses();
  const newCourse: Course = {
    ...course,
    id: generateId(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  courses.push(newCourse);
  localStorage.setItem('techno_courses', JSON.stringify(courses));
  return newCourse;
};

export const updateCourse = (id: string, course: Partial<Course>): Course | null => {
  const courses = getCourses();
  const index = courses.findIndex(c => c.id === id);
  if (index === -1) return null;
  courses[index] = { ...courses[index], ...course, updatedAt: new Date().toISOString() };
  localStorage.setItem('techno_courses', JSON.stringify(courses));
  return courses[index];
};

export const deleteCourse = (id: string): void => {
  const courses = getCourses().filter(c => c.id !== id);
  localStorage.setItem('techno_courses', JSON.stringify(courses));
};

// Evaluations
export const getEvaluations = (): Evaluation[] => {
  const data = localStorage.getItem('techno_evaluations');
  return data ? JSON.parse(data) : [];
};

export const saveEvaluation = (evaluation: Omit<Evaluation, 'id' | 'createdAt'>): Evaluation => {
  const evaluations = getEvaluations();
  const newEval: Evaluation = {
    ...evaluation,
    id: generateId(),
    createdAt: new Date().toISOString(),
  };
  evaluations.push(newEval);
  localStorage.setItem('techno_evaluations', JSON.stringify(evaluations));
  return newEval;
};

export const updateEvaluation = (id: string, evaluation: Partial<Evaluation>): Evaluation | null => {
  const evaluations = getEvaluations();
  const index = evaluations.findIndex(e => e.id === id);
  if (index === -1) return null;
  evaluations[index] = { ...evaluations[index], ...evaluation };
  localStorage.setItem('techno_evaluations', JSON.stringify(evaluations));
  return evaluations[index];
};

export const deleteEvaluation = (id: string): void => {
  const evaluations = getEvaluations().filter(e => e.id !== id);
  localStorage.setItem('techno_evaluations', JSON.stringify(evaluations));
};

// Results
export const getResults = (): StudentResult[] => {
  const data = localStorage.getItem('techno_results');
  return data ? JSON.parse(data) : [];
};

export const saveResult = (result: Omit<StudentResult, 'id' | 'submittedAt'>): StudentResult => {
  const results = getResults();
  const newResult: StudentResult = {
    ...result,
    id: generateId(),
    submittedAt: new Date().toISOString(),
  };
  results.push(newResult);
  localStorage.setItem('techno_results', JSON.stringify(results));
  return newResult;
};

export const deleteResult = (id: string): void => {
  const results = getResults().filter(r => r.id !== id);
  localStorage.setItem('techno_results', JSON.stringify(results));
};

export const deleteResultsByEvaluation = (evaluationId: string): void => {
  const results = getResults().filter(r => r.evaluationId !== evaluationId);
  localStorage.setItem('techno_results', JSON.stringify(results));
};

// Admin password
const ADMIN_PASSWORD_KEY = 'techno_admin_password';
const DEFAULT_PASSWORD = 'prof2024';

export const getAdminPassword = (): string => {
  return localStorage.getItem(ADMIN_PASSWORD_KEY) || DEFAULT_PASSWORD;
};

export const setAdminPassword = (password: string): void => {
  localStorage.setItem(ADMIN_PASSWORD_KEY, password);
};

export const verifyAdminPassword = (password: string): boolean => {
  return password === getAdminPassword();
};

// Seed data
export const seedDemoData = () => {
  if (getCourses().length > 0) return;
  
  const course1 = saveCourse({
    title: "Les matériaux et leurs propriétés",
    level: "6ème",
    description: "Découverte des différentes familles de matériaux utilisés en technologie.",
    content: `# Les matériaux et leurs propriétés

## Introduction
En technologie, nous utilisons de nombreux matériaux différents pour fabriquer des objets. Chaque matériau a des propriétés spécifiques qui le rendent adapté à certains usages.

## Les familles de matériaux

### 1. Les métaux
- **Exemples** : fer, aluminium, cuivre, acier
- **Propriétés** : conducteurs, résistants, recyclables
- **Utilisations** : structures, câbles électriques, carrosseries

### 2. Les plastiques (polymères)
- **Exemples** : PVC, polyéthylène, polystyrène
- **Propriétés** : légers, isolants, moulables
- **Utilisations** : emballages, jouets, tuyaux

### 3. Les céramiques
- **Exemples** : verre, porcelaine, terre cuite
- **Propriétés** : durs, fragiles, résistants à la chaleur
- **Utilisations** : vaisselle, carrelage, briques

### 4. Les matériaux organiques
- **Exemples** : bois, cuir, coton, papier
- **Propriétés** : biodégradables, renouvelables
- **Utilisations** : meubles, vêtements, livres

### 5. Les matériaux composites
- **Exemples** : fibre de carbone, béton armé
- **Propriétés** : très résistants, légers
- **Utilisations** : avions, bateaux, ponts

## Les propriétés des matériaux
- **Mécanique** : résistance, élasticité, dureté
- **Thermique** : conductivité, résistance à la chaleur
- **Électrique** : conducteur ou isolant
- **Esthétique** : couleur, brillance, texture`,
    attachments: [],
  });

  saveCourse({
    title: "L'énergie et ses transformations",
    level: "5ème",
    description: "Comprendre les différentes formes d'énergie et comment elles se transforment.",
    content: `# L'énergie et ses transformations

## Les formes d'énergie
- Énergie cinétique (mouvement)
- Énergie potentielle (position)
- Énergie thermique (chaleur)
- Énergie électrique
- Énergie lumineuse
- Énergie chimique

## Les sources d'énergie
### Renouvelables
- Solaire, éolienne, hydraulique, biomasse, géothermique

### Non renouvelables
- Pétrole, gaz naturel, charbon, nucléaire

## Les chaînes d'énergie
Une chaîne d'énergie décrit les transformations depuis la source jusqu'à l'utilisation finale.

**Exemple** : Panneau solaire → Convertisseur → Batterie → Moteur → Mouvement`,
    attachments: [],
  });

  saveCourse({
    title: "La programmation avec Scratch",
    level: "4ème",
    description: "Initiation à la programmation par blocs avec Scratch.",
    content: `# La programmation avec Scratch

## Qu'est-ce qu'un algorithme ?
Un algorithme est une suite d'instructions ordonnées pour résoudre un problème.

## Les blocs Scratch
### Mouvement
- Avancer, tourner, aller à une position

### Apparence
- Dire, changer de costume, montrer/cacher

### Contrôle
- Si...alors, répéter, attendre

### Événements
- Quand le drapeau est cliqué, quand une touche est pressée

### Capteurs
- Touche pressée, souris, distance

## Exercice pratique
Créer un programme qui fait se déplacer un personnage avec les flèches du clavier.`,
    attachments: [],
  });

  // Create evaluations
  saveEvaluation({
    title: "Évaluation - Les matériaux",
    level: "6ème",
    courseId: course1.id,
    description: "Évaluation sur les familles de matériaux et leurs propriétés",
    duration: 20,
    isActive: true,
    questions: [
      {
        id: generateId(),
        text: "À quelle famille de matériaux appartient l'aluminium ?",
        type: 'qcm',
        options: ['Les plastiques', 'Les métaux', 'Les céramiques', 'Les composites'],
        correctAnswer: 'Les métaux',
        points: 2,
      },
      {
        id: generateId(),
        text: "Le bois est un matériau organique.",
        type: 'truefalse',
        correctAnswer: 'vrai',
        points: 1,
      },
      {
        id: generateId(),
        text: "Le PVC est un matériau conducteur d'électricité.",
        type: 'truefalse',
        correctAnswer: 'faux',
        points: 1,
      },
      {
        id: generateId(),
        text: "Citez deux propriétés des matériaux métalliques.",
        type: 'text',
        correctAnswer: 'conducteurs résistants recyclables',
        points: 2,
      },
      {
        id: generateId(),
        text: "Quel matériau composite est utilisé dans la construction des avions ?",
        type: 'qcm',
        options: ['Le béton', 'La fibre de carbone', 'Le PVC', 'Le bois'],
        correctAnswer: 'La fibre de carbone',
        points: 2,
      },
      {
        id: generateId(),
        text: "Le verre appartient à la famille des céramiques.",
        type: 'truefalse',
        correctAnswer: 'vrai',
        points: 1,
      },
      {
        id: generateId(),
        text: "Donnez un exemple d'utilisation du cuivre et expliquez pourquoi ce matériau est adapté.",
        type: 'text',
        correctAnswer: 'câbles électriques conducteur',
        points: 3,
      },
    ],
  });

  saveEvaluation({
    title: "Quiz - L'énergie",
    level: "5ème",
    description: "Quiz rapide sur les formes et sources d'énergie",
    duration: 15,
    isActive: true,
    questions: [
      {
        id: generateId(),
        text: "L'énergie solaire est une énergie renouvelable.",
        type: 'truefalse',
        correctAnswer: 'vrai',
        points: 1,
      },
      {
        id: generateId(),
        text: "Quelle forme d'énergie est liée au mouvement ?",
        type: 'qcm',
        options: ['Énergie thermique', 'Énergie cinétique', 'Énergie potentielle', 'Énergie chimique'],
        correctAnswer: 'Énergie cinétique',
        points: 2,
      },
      {
        id: generateId(),
        text: "Le pétrole est une source d'énergie renouvelable.",
        type: 'truefalse',
        correctAnswer: 'faux',
        points: 1,
      },
      {
        id: generateId(),
        text: "Citez 3 sources d'énergie renouvelable.",
        type: 'text',
        correctAnswer: 'solaire éolienne hydraulique biomasse géothermique',
        points: 3,
      },
    ],
  });
};
