import { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { StudentHome } from './components/StudentHome';
import { CourseList } from './components/CourseList';
import { EvaluationList } from './components/EvaluationList';
import { AdminLogin } from './components/AdminLogin';
import { AdminDashboard } from './components/AdminDashboard';
import { AdminCourses } from './components/AdminCourses';
import { AdminEvaluations } from './components/AdminEvaluations';
import { AdminResults } from './components/AdminResults';
import { AdminSettings } from './components/AdminSettings';
import { seedDemoData } from './store/dataStore';

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    seedDemoData();
  }, []);

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
    window.scrollTo(0, 0);
  };

  const handleLogin = () => {
    setIsAdmin(true);
    setCurrentPage('admin-dashboard');
  };

  const handleLogout = () => {
    setIsAdmin(false);
    setCurrentPage('home');
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <StudentHome onNavigate={handleNavigate} />;
      case 'courses':
        return <CourseList />;
      case 'evaluations':
        return <EvaluationList />;
      case 'admin-login':
        return <AdminLogin onLogin={handleLogin} onBack={() => handleNavigate('home')} />;
      case 'admin-dashboard':
        return <AdminDashboard onNavigate={handleNavigate} />;
      case 'admin-courses':
        return <AdminCourses />;
      case 'admin-evaluations':
        return <AdminEvaluations />;
      case 'admin-results':
        return <AdminResults />;
      case 'admin-settings':
        return <AdminSettings />;
      default:
        return <StudentHome onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar
        currentPage={currentPage}
        onNavigate={handleNavigate}
        isAdmin={isAdmin}
        onLogout={handleLogout}
      />
      <main className="max-w-7xl mx-auto px-4 py-8">
        {renderPage()}
      </main>
      <footer className="bg-white border-t border-gray-100 mt-16 py-6">
        <div className="max-w-7xl mx-auto px-4 text-center text-sm text-gray-400">
          <p>🎓 TechnoCollège — Plateforme pédagogique de Technologie au Collège</p>
          <p className="mt-1">© {new Date().getFullYear()} — Tous droits réservés</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
