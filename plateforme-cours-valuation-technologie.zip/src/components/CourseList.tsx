import React, { useState } from 'react';
import { BookOpen, ArrowLeft, Calendar, Tag, Search } from 'lucide-react';
import { getCourses, Course } from '../store/dataStore';
import { cn } from '../utils/cn';

export const CourseList: React.FC = () => {
  const [courses] = useState<Course[]>(getCourses());
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [filterLevel, setFilterLevel] = useState('');
  const [search, setSearch] = useState('');

  const levels = [...new Set(courses.map(c => c.level))];

  const filtered = courses.filter(c => {
    if (filterLevel && c.level !== filterLevel) return false;
    if (search && !c.title.toLowerCase().includes(search.toLowerCase()) && !c.description.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const levelColors: Record<string, string> = {
    '6ème': 'bg-emerald-100 text-emerald-700',
    '5ème': 'bg-blue-100 text-blue-700',
    '4ème': 'bg-purple-100 text-purple-700',
    '3ème': 'bg-orange-100 text-orange-700',
  };

  if (selectedCourse) {
    return (
      <div className="space-y-6">
        <button
          onClick={() => setSelectedCourse(null)}
          className="flex items-center gap-2 text-blue-600 hover:text-blue-800 font-medium transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Retour aux cours
        </button>
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-8 text-white">
            <span className={cn('px-3 py-1 rounded-full text-xs font-bold bg-white/20')}>
              {selectedCourse.level}
            </span>
            <h1 className="text-2xl md:text-3xl font-bold mt-3">{selectedCourse.title}</h1>
            <p className="text-blue-100 mt-2">{selectedCourse.description}</p>
            <div className="flex items-center gap-4 mt-4 text-blue-200 text-sm">
              <span className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                {new Date(selectedCourse.createdAt).toLocaleDateString('fr-FR')}
              </span>
            </div>
          </div>
          <div className="p-6 md:p-8">
            <div className="prose prose-lg max-w-none">
              {selectedCourse.content.split('\n').map((line, i) => {
                if (line.startsWith('# ')) return <h1 key={i} className="text-2xl font-bold text-gray-800 mt-6 mb-3">{line.substring(2)}</h1>;
                if (line.startsWith('## ')) return <h2 key={i} className="text-xl font-bold text-gray-700 mt-5 mb-2 border-b border-gray-200 pb-2">{line.substring(3)}</h2>;
                if (line.startsWith('### ')) return <h3 key={i} className="text-lg font-semibold text-gray-600 mt-4 mb-2">{line.substring(4)}</h3>;
                if (line.startsWith('- **')) {
                  const parts = line.substring(2).split('**');
                  return (
                    <div key={i} className="flex items-start gap-2 ml-4 my-1">
                      <span className="w-2 h-2 bg-blue-400 rounded-full mt-2 flex-shrink-0"></span>
                      <p><strong className="text-gray-800">{parts[1]}</strong>{parts[2]}</p>
                    </div>
                  );
                }
                if (line.startsWith('- ')) return (
                  <div key={i} className="flex items-start gap-2 ml-4 my-1">
                    <span className="w-2 h-2 bg-blue-400 rounded-full mt-2 flex-shrink-0"></span>
                    <p className="text-gray-600">{line.substring(2)}</p>
                  </div>
                );
                if (line.startsWith('**') && line.endsWith('**')) return <p key={i} className="font-bold text-gray-700 mt-3">{line.replace(/\*\*/g, '')}</p>;
                if (line.trim() === '') return <div key={i} className="h-2"></div>;
                return <p key={i} className="text-gray-600 my-1">{line}</p>;
              })}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-800">📚 Cours de Technologie</h1>
        <p className="text-gray-500 mt-1">Retrouve tous tes cours classés par niveau</p>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 items-center">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Rechercher un cours..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-300 focus:border-blue-400 outline-none transition-all"
          />
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setFilterLevel('')}
            className={cn(
              'px-4 py-2 rounded-xl text-sm font-medium transition-all',
              !filterLevel ? 'bg-blue-600 text-white shadow-md' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            )}
          >
            Tous
          </button>
          {levels.map((level) => (
            <button
              key={level}
              onClick={() => setFilterLevel(level)}
              className={cn(
                'px-4 py-2 rounded-xl text-sm font-medium transition-all',
                filterLevel === level ? 'bg-blue-600 text-white shadow-md' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              )}
            >
              {level}
            </button>
          ))}
        </div>
      </div>

      {/* Course Grid */}
      {filtered.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-gray-100">
          <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-500">Aucun cours trouvé</h3>
          <p className="text-gray-400 text-sm">Les cours apparaîtront ici quand ton professeur les ajoutera.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((course) => (
            <div
              key={course.id}
              onClick={() => setSelectedCourse(course)}
              className="bg-white rounded-2xl shadow-sm border border-gray-100 hover:shadow-lg transition-all cursor-pointer group transform hover:-translate-y-1"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <span className={cn('px-3 py-1 rounded-full text-xs font-bold', levelColors[course.level] || 'bg-gray-100 text-gray-600')}>
                    <Tag className="w-3 h-3 inline mr-1" />
                    {course.level}
                  </span>
                  <span className="text-xs text-gray-400">
                    {new Date(course.createdAt).toLocaleDateString('fr-FR')}
                  </span>
                </div>
                <h3 className="text-lg font-bold text-gray-800 group-hover:text-blue-600 transition-colors mb-2">
                  {course.title}
                </h3>
                <p className="text-gray-500 text-sm line-clamp-2">{course.description}</p>
                <div className="mt-4 flex items-center text-blue-600 text-sm font-medium group-hover:gap-2 transition-all">
                  <BookOpen className="w-4 h-4 mr-1" />
                  Lire le cours →
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
