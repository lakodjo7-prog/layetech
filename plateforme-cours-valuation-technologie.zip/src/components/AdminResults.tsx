import React, { useState } from 'react';
import { Download, Trash2, Eye, Users, ChevronDown, ChevronUp, Filter } from 'lucide-react';
import { getResults, getEvaluations, deleteResult, StudentResult, Evaluation } from '../store/dataStore';
import { cn } from '../utils/cn';

export const AdminResults: React.FC = () => {
  const [results, setResults] = useState<StudentResult[]>(getResults());
  const [evaluations] = useState<Evaluation[]>(getEvaluations());
  const [filterEval, setFilterEval] = useState('');
  const [filterClass, setFilterClass] = useState('');
  const [sortBy, setSortBy] = useState<'date' | 'name' | 'score'>('date');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [expandedResult, setExpandedResult] = useState<string | null>(null);

  const refresh = () => setResults(getResults());

  const handleDelete = (id: string) => {
    if (confirm('Supprimer ce résultat ?')) {
      deleteResult(id);
      refresh();
    }
  };

  const classes = [...new Set(results.map(r => r.studentClass))].sort();

  const filtered = results.filter(r => {
    if (filterEval && r.evaluationId !== filterEval) return false;
    if (filterClass && r.studentClass !== filterClass) return false;
    return true;
  });

  const sorted = [...filtered].sort((a, b) => {
    let cmp = 0;
    if (sortBy === 'date') cmp = new Date(a.submittedAt).getTime() - new Date(b.submittedAt).getTime();
    if (sortBy === 'name') cmp = a.studentName.localeCompare(b.studentName);
    if (sortBy === 'score') cmp = a.percentage - b.percentage;
    return sortDir === 'desc' ? -cmp : cmp;
  });

  const avgPercentage = filtered.length > 0
    ? filtered.reduce((sum, r) => sum + r.percentage, 0) / filtered.length
    : 0;
  
  const bestScore = filtered.length > 0 ? Math.max(...filtered.map(r => r.percentage)) : 0;
  const worstScore = filtered.length > 0 ? Math.min(...filtered.map(r => r.percentage)) : 0;

  const exportCSV = () => {
    const headers = ['Nom', 'Classe', 'Évaluation', 'Score', 'Max', 'Pourcentage', 'Date'];
    const rows = sorted.map(r => {
      const evalTitle = evaluations.find(e => e.id === r.evaluationId)?.title || 'Inconnu';
      return [
        r.studentName,
        r.studentClass,
        evalTitle,
        r.totalScore,
        r.maxScore,
        `${r.percentage.toFixed(1)}%`,
        new Date(r.submittedAt).toLocaleDateString('fr-FR'),
      ];
    });
    const csv = [headers, ...rows].map(row => row.join(';')).join('\n');
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `resultats_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const toggleSort = (field: 'date' | 'name' | 'score') => {
    if (sortBy === field) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortDir('desc');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">📊 Résultats des évaluations</h1>
          <p className="text-gray-500 mt-1">{results.length} copie(s) rendue(s) au total</p>
        </div>
        <button
          onClick={exportCSV}
          disabled={sorted.length === 0}
          className="flex items-center gap-2 bg-emerald-600 text-white font-bold px-5 py-3 rounded-xl hover:bg-emerald-700 transition-all shadow-md disabled:opacity-50"
        >
          <Download className="w-5 h-5" /> Exporter CSV
        </button>
      </div>

      {/* Stats */}
      {filtered.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
            <p className="text-sm text-gray-500">Copies</p>
            <p className="text-2xl font-bold text-gray-800">{filtered.length}</p>
          </div>
          <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
            <p className="text-sm text-gray-500">Moyenne</p>
            <p className={cn('text-2xl font-bold', avgPercentage >= 50 ? 'text-green-600' : 'text-red-500')}>
              {avgPercentage.toFixed(1)}%
            </p>
          </div>
          <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
            <p className="text-sm text-gray-500">Meilleur</p>
            <p className="text-2xl font-bold text-green-600">{bestScore.toFixed(1)}%</p>
          </div>
          <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
            <p className="text-sm text-gray-500">Plus bas</p>
            <p className="text-2xl font-bold text-red-500">{worstScore.toFixed(1)}%</p>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-wrap gap-3 items-center bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
        <Filter className="w-5 h-5 text-gray-400" />
        <select
          value={filterEval}
          onChange={(e) => setFilterEval(e.target.value)}
          className="px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none focus:ring-2 focus:ring-blue-300"
        >
          <option value="">Toutes les évaluations</option>
          {evaluations.map(e => (
            <option key={e.id} value={e.id}>{e.title}</option>
          ))}
        </select>
        <select
          value={filterClass}
          onChange={(e) => setFilterClass(e.target.value)}
          className="px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none focus:ring-2 focus:ring-blue-300"
        >
          <option value="">Toutes les classes</option>
          {classes.map(c => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>

        <div className="flex gap-1 ml-auto">
          {(['date', 'name', 'score'] as const).map(field => (
            <button
              key={field}
              onClick={() => toggleSort(field)}
              className={cn(
                'px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1',
                sortBy === field ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
              )}
            >
              {field === 'date' ? 'Date' : field === 'name' ? 'Nom' : 'Score'}
              {sortBy === field && (sortDir === 'desc' ? <ChevronDown className="w-3 h-3" /> : <ChevronUp className="w-3 h-3" />)}
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      {sorted.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-gray-100">
          <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-500">Aucun résultat</h3>
          <p className="text-gray-400 text-sm">Les résultats des élèves apparaîtront ici</p>
        </div>
      ) : (
        <div className="space-y-3">
          {sorted.map((result) => {
            const evaluation = evaluations.find(e => e.id === result.evaluationId);
            const isExpanded = expandedResult === result.id;

            return (
              <div key={result.id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-all">
                <div className="p-4 px-5 flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                      <h3 className="font-bold text-gray-800">{result.studentName}</h3>
                      <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-600">
                        {result.studentClass}
                      </span>
                    </div>
                    <p className="text-sm text-gray-400">
                      {evaluation?.title || 'Évaluation supprimée'} •{' '}
                      {new Date(result.submittedAt).toLocaleDateString('fr-FR', { 
                        day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' 
                      })}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <p className={cn('text-xl font-bold', result.percentage >= 50 ? 'text-green-600' : 'text-red-500')}>
                        {result.totalScore}/{result.maxScore}
                      </p>
                      <div className="w-24 bg-gray-100 rounded-full h-2 mt-1">
                        <div
                          className={cn('h-full rounded-full',
                            result.percentage >= 75 ? 'bg-green-500' :
                            result.percentage >= 50 ? 'bg-yellow-500' : 'bg-red-500'
                          )}
                          style={{ width: `${result.percentage}%` }}
                        />
                      </div>
                    </div>
                    <button onClick={() => setExpandedResult(isExpanded ? null : result.id)} className="p-2 rounded-lg text-blue-600 hover:bg-blue-50">
                      <Eye className="w-4 h-4" />
                    </button>
                    <button onClick={() => handleDelete(result.id)} className="p-2 rounded-lg text-red-500 hover:bg-red-50">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {isExpanded && evaluation && (
                  <div className="border-t border-gray-100 p-5 bg-gray-50 space-y-3">
                    <h4 className="font-bold text-gray-700 text-sm">Détail des réponses :</h4>
                    {result.answers.map((ans, i) => {
                      const question = evaluation.questions.find(q => q.id === ans.questionId);
                      return (
                        <div key={ans.questionId} className={cn(
                          'p-3 rounded-lg border text-sm',
                          ans.isCorrect ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
                        )}>
                          <p className="font-medium text-gray-700">
                            <span className="text-gray-400">Q{i + 1}.</span> {question?.text || 'Question supprimée'}
                            <span className="ml-2 text-xs font-bold">{ans.points}/{question?.points || 0} pt</span>
                          </p>
                          <p className="mt-1 text-gray-600">
                            <span className="font-medium">Réponse :</span> {ans.answer || <em className="text-gray-400">Pas de réponse</em>}
                          </p>
                          {!ans.isCorrect && question && (
                            <p className="mt-1 text-green-700">
                              <span className="font-medium">Réponse attendue :</span> {question.correctAnswer}
                            </p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
