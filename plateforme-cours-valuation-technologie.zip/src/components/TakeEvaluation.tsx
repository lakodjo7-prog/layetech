import React, { useState, useEffect, useCallback } from 'react';
import { ArrowLeft, ArrowRight, Clock, Send, AlertTriangle } from 'lucide-react';
import { Evaluation, Question, StudentResult, saveResult } from '../store/dataStore';
import { cn } from '../utils/cn';

interface TakeEvaluationProps {
  evaluation: Evaluation;
  onComplete: (result: StudentResult) => void;
  onBack: () => void;
}

export const TakeEvaluation: React.FC<TakeEvaluationProps> = ({ evaluation, onComplete, onBack }) => {
  const [step, setStep] = useState<'info' | 'quiz' | 'confirm'>('info');
  const [studentName, setStudentName] = useState('');
  const [studentClass, setStudentClass] = useState('');
  const [currentQ, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [timeLeft, setTimeLeft] = useState(evaluation.duration * 60);

  const handleSubmit = useCallback(() => {
    const resultAnswers = evaluation.questions.map((q) => {
      const studentAnswer = answers[q.id] || '';
      let isCorrect = false;

      if (q.type === 'qcm' || q.type === 'truefalse') {
        isCorrect = studentAnswer.toLowerCase().trim() === q.correctAnswer.toLowerCase().trim();
      } else {
        // For text questions, check if key words are present
        const keywords = q.correctAnswer.toLowerCase().split(' ');
        const matchCount = keywords.filter(kw => studentAnswer.toLowerCase().includes(kw)).length;
        isCorrect = matchCount >= Math.ceil(keywords.length * 0.4);
      }

      return {
        questionId: q.id,
        answer: studentAnswer,
        isCorrect,
        points: isCorrect ? q.points : 0,
      };
    });

    const totalScore = resultAnswers.reduce((sum, a) => sum + a.points, 0);
    const maxScore = evaluation.questions.reduce((sum, q) => sum + q.points, 0);

    const result = saveResult({
      evaluationId: evaluation.id,
      studentName,
      studentClass,
      answers: resultAnswers,
      totalScore,
      maxScore,
      percentage: maxScore > 0 ? (totalScore / maxScore) * 100 : 0,
    });

    onComplete(result);
  }, [answers, evaluation, studentName, studentClass, onComplete]);

  useEffect(() => {
    if (step !== 'quiz') return;
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [step, handleSubmit]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const setAnswer = (questionId: string, answer: string) => {
    setAnswers(prev => ({ ...prev, [questionId]: answer }));
  };

  const question: Question | undefined = evaluation.questions[currentQ];

  // Info step
  if (step === 'info') {
    return (
      <div className="max-w-xl mx-auto space-y-6">
        <button onClick={onBack} className="flex items-center gap-2 text-blue-600 hover:text-blue-800 font-medium">
          <ArrowLeft className="w-4 h-4" /> Retour
        </button>
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-2">{evaluation.title}</h2>
          <p className="text-gray-500 mb-6">{evaluation.description}</p>
          <div className="bg-blue-50 rounded-xl p-4 mb-6 text-sm text-blue-700 space-y-1">
            <p>⏱ Durée : <strong>{evaluation.duration} minutes</strong></p>
            <p>📝 Questions : <strong>{evaluation.questions.length}</strong></p>
            <p>🏆 Total : <strong>{evaluation.questions.reduce((s, q) => s + q.points, 0)} points</strong></p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Ton nom et prénom *</label>
              <input
                type="text"
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
                placeholder="Ex: Martin Dupont"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-300 focus:border-blue-400 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Ta classe *</label>
              <select
                value={studentClass}
                onChange={(e) => setStudentClass(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-300 focus:border-blue-400 outline-none"
              >
                <option value="">Sélectionne ta classe</option>
                <option value="6ème A">6ème A</option>
                <option value="6ème B">6ème B</option>
                <option value="6ème C">6ème C</option>
                <option value="5ème A">5ème A</option>
                <option value="5ème B">5ème B</option>
                <option value="5ème C">5ème C</option>
                <option value="4ème A">4ème A</option>
                <option value="4ème B">4ème B</option>
                <option value="4ème C">4ème C</option>
                <option value="3ème A">3ème A</option>
                <option value="3ème B">3ème B</option>
                <option value="3ème C">3ème C</option>
              </select>
            </div>
          </div>

          <button
            onClick={() => { if (studentName.trim() && studentClass) setStep('quiz'); }}
            disabled={!studentName.trim() || !studentClass}
            className="w-full mt-6 bg-blue-600 text-white font-bold py-3 rounded-xl hover:bg-blue-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-md"
          >
            Commencer l'évaluation
          </button>
        </div>
      </div>
    );
  }

  // Confirm step
  if (step === 'confirm') {
    const unanswered = evaluation.questions.filter(q => !answers[q.id]?.trim()).length;
    return (
      <div className="max-w-lg mx-auto text-center space-y-6 py-8">
        <AlertTriangle className="w-16 h-16 text-yellow-500 mx-auto" />
        <h2 className="text-2xl font-bold text-gray-800">Confirmer l'envoi ?</h2>
        {unanswered > 0 && (
          <p className="text-red-500 font-medium">⚠️ {unanswered} question{unanswered > 1 ? 's' : ''} sans réponse !</p>
        )}
        <p className="text-gray-500">Une fois envoyé, tu ne pourras plus modifier tes réponses.</p>
        <div className="flex gap-4 justify-center">
          <button
            onClick={() => setStep('quiz')}
            className="px-6 py-3 rounded-xl border border-gray-300 text-gray-700 font-medium hover:bg-gray-50 transition-all"
          >
            Revenir au quiz
          </button>
          <button
            onClick={handleSubmit}
            className="px-6 py-3 rounded-xl bg-green-600 text-white font-bold hover:bg-green-700 transition-all shadow-md"
          >
            Confirmer et envoyer
          </button>
        </div>
      </div>
    );
  }

  // Quiz step
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-4 flex items-center justify-between sticky top-0 z-10">
        <div>
          <h2 className="font-bold text-gray-800 text-sm md:text-base">{evaluation.title}</h2>
          <p className="text-xs text-gray-400">{studentName} • {studentClass}</p>
        </div>
        <div className={cn(
          'flex items-center gap-2 px-4 py-2 rounded-xl font-mono font-bold',
          timeLeft < 60 ? 'bg-red-100 text-red-600 animate-pulse' :
          timeLeft < 300 ? 'bg-yellow-100 text-yellow-600' :
          'bg-blue-100 text-blue-600'
        )}>
          <Clock className="w-4 h-4" />
          {formatTime(timeLeft)}
        </div>
      </div>

      {/* Progress */}
      <div className="flex gap-1.5">
        {evaluation.questions.map((q, i) => (
          <button
            key={q.id}
            onClick={() => setCurrentQ(i)}
            className={cn(
              'h-2 rounded-full flex-1 transition-all',
              i === currentQ ? 'bg-blue-600' :
              answers[q.id]?.trim() ? 'bg-green-400' : 'bg-gray-200'
            )}
          />
        ))}
      </div>

      {/* Question */}
      {question && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 md:p-8">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-medium text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
              Question {currentQ + 1} / {evaluation.questions.length}
            </span>
            <span className="text-sm text-gray-400">{question.points} point{question.points > 1 ? 's' : ''}</span>
          </div>

          <h3 className="text-lg font-bold text-gray-800 mb-6">{question.text}</h3>

          {question.type === 'qcm' && question.options && (
            <div className="space-y-3">
              {question.options.map((option) => (
                <button
                  key={option}
                  onClick={() => setAnswer(question.id, option)}
                  className={cn(
                    'w-full text-left px-5 py-4 rounded-xl border-2 transition-all font-medium',
                    answers[question.id] === option
                      ? 'border-blue-500 bg-blue-50 text-blue-700 shadow-md'
                      : 'border-gray-200 hover:border-blue-300 hover:bg-blue-50/50 text-gray-700'
                  )}
                >
                  <span className={cn(
                    'inline-flex items-center justify-center w-7 h-7 rounded-full mr-3 text-sm font-bold',
                    answers[question.id] === option
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-500'
                  )}>
                    {String.fromCharCode(65 + question.options!.indexOf(option))}
                  </span>
                  {option}
                </button>
              ))}
            </div>
          )}

          {question.type === 'truefalse' && (
            <div className="flex gap-4">
              {['vrai', 'faux'].map((val) => (
                <button
                  key={val}
                  onClick={() => setAnswer(question.id, val)}
                  className={cn(
                    'flex-1 py-4 rounded-xl border-2 font-bold text-lg transition-all',
                    answers[question.id] === val
                      ? val === 'vrai'
                        ? 'border-green-500 bg-green-50 text-green-700 shadow-md'
                        : 'border-red-500 bg-red-50 text-red-700 shadow-md'
                      : 'border-gray-200 hover:border-gray-300 text-gray-600'
                  )}
                >
                  {val === 'vrai' ? '✅ Vrai' : '❌ Faux'}
                </button>
              ))}
            </div>
          )}

          {question.type === 'text' && (
            <textarea
              value={answers[question.id] || ''}
              onChange={(e) => setAnswer(question.id, e.target.value)}
              placeholder="Écris ta réponse ici..."
              rows={4}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-300 focus:border-blue-400 outline-none resize-none"
            />
          )}
        </div>
      )}

      {/* Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => setCurrentQ(prev => Math.max(0, prev - 1))}
          disabled={currentQ === 0}
          className="flex items-center gap-2 px-5 py-3 rounded-xl border border-gray-200 text-gray-700 font-medium hover:bg-gray-50 transition-all disabled:opacity-40"
        >
          <ArrowLeft className="w-4 h-4" /> Précédent
        </button>

        {currentQ < evaluation.questions.length - 1 ? (
          <button
            onClick={() => setCurrentQ(prev => prev + 1)}
            className="flex items-center gap-2 px-5 py-3 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-700 transition-all shadow-md"
          >
            Suivant <ArrowRight className="w-4 h-4" />
          </button>
        ) : (
          <button
            onClick={() => setStep('confirm')}
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-green-600 text-white font-bold hover:bg-green-700 transition-all shadow-md"
          >
            <Send className="w-4 h-4" /> Terminer
          </button>
        )}
      </div>
    </div>
  );
};
