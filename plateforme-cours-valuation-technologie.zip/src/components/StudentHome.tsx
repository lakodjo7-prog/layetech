import React from 'react';
import { BookOpen, ClipboardCheck, Lightbulb, Cpu, Wrench, Zap } from 'lucide-react';

interface StudentHomeProps {
  onNavigate: (page: string) => void;
}

export const StudentHome: React.FC<StudentHomeProps> = ({ onNavigate }) => {
  return (
    <div className="space-y-8">
      {/* Hero */}
      <div className="bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-700 rounded-3xl p-8 md:p-12 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 right-10 w-40 h-40 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 left-10 w-60 h-60 bg-yellow-300 rounded-full blur-3xl"></div>
        </div>
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-4">
            <Cpu className="w-10 h-10 text-yellow-300" />
            <span className="bg-yellow-300/20 text-yellow-200 text-sm px-3 py-1 rounded-full">Technologie au Collège</span>
          </div>
          <h1 className="text-3xl md:text-5xl font-extrabold mb-4">
            Bienvenue sur <span className="text-yellow-300">LayeTech</span>
          </h1>
          <p className="text-lg text-blue-100 max-w-2xl mb-8">
            Retrouve ici tous tes cours de technologie, révise et passe tes évaluations en ligne. 
            Bonne réussite ! 🚀
          </p>
          <div className="flex flex-wrap gap-4">
            <button
              onClick={() => onNavigate('courses')}
              className="flex items-center gap-2 bg-white text-indigo-700 font-bold px-6 py-3 rounded-xl hover:bg-blue-50 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            >
              <BookOpen className="w-5 h-5" />
              Voir les cours
            </button>
            <button
              onClick={() => onNavigate('evaluations')}
              className="flex items-center gap-2 bg-yellow-400 text-indigo-900 font-bold px-6 py-3 rounded-xl hover:bg-yellow-300 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            >
              <ClipboardCheck className="w-5 h-5" />
              Passer une évaluation
            </button>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-all group">
          <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-4 group-hover:bg-blue-200 transition-all">
            <BookOpen className="w-6 h-6 text-blue-600" />
          </div>
          <h3 className="text-lg font-bold text-gray-800 mb-2">📚 Cours en ligne</h3>
          <p className="text-gray-500 text-sm">
            Accède à tous les cours de technologie organisés par niveau. Révise à ton rythme depuis chez toi.
          </p>
        </div>
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-all group">
          <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mb-4 group-hover:bg-green-200 transition-all">
            <ClipboardCheck className="w-6 h-6 text-green-600" />
          </div>
          <h3 className="text-lg font-bold text-gray-800 mb-2">✅ Évaluations interactives</h3>
          <p className="text-gray-500 text-sm">
            Passe tes évaluations en ligne : QCM, Vrai/Faux et questions ouvertes. Résultats immédiats !
          </p>
        </div>
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-all group">
          <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mb-4 group-hover:bg-purple-200 transition-all">
            <Lightbulb className="w-6 h-6 text-purple-600" />
          </div>
          <h3 className="text-lg font-bold text-gray-800 mb-2">💡 Apprendre en s'amusant</h3>
          <p className="text-gray-500 text-sm">
            La technologie, c'est comprendre le monde qui nous entoure : matériaux, énergie, programmation...
          </p>
        </div>
      </div>

      {/* Themes */}
      <div>
        <h2 className="text-2xl font-bold text-gray-800 mb-6">🔬 Thèmes abordés en technologie</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { icon: Wrench, label: 'Matériaux', color: 'bg-orange-100 text-orange-600' },
            { icon: Zap, label: 'Énergie', color: 'bg-yellow-100 text-yellow-600' },
            { icon: Cpu, label: 'Programmation', color: 'bg-blue-100 text-blue-600' },
            { icon: Lightbulb, label: 'Innovation', color: 'bg-green-100 text-green-600' },
          ].map((theme) => (
            <div key={theme.label} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 flex items-center gap-3 hover:shadow-md transition-all cursor-pointer" onClick={() => onNavigate('courses')}>
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${theme.color}`}>
                <theme.icon className="w-5 h-5" />
              </div>
              <span className="font-semibold text-gray-700">{theme.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
