import React, { useState } from 'react';
import { Plus, Edit, Trash2, BookOpen, X, Save } from 'lucide-react';
import { getCourses, saveCourse, updateCourse, deleteCourse, Course } from '../store/dataStore';
import { cn } from '../utils/cn';

export const AdminCourses: React.FC = () => {
  const [courses, setCourses] = useState<Course[]>(getCourses());
  const [editing, setEditing] = useState<Course | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({ title: '', level: '6ème', description: '', content: '' });

  const refresh = () => setCourses(getCourses());

  const handleCreate = () => {
    if (!form.title.trim() || !form.content.trim()) return;
    saveCourse({ ...form, attachments: [] });
    setForm({ title: '', level: '6ème', description: '', content: '' });
    setCreating(false);
    refresh();
  };

  const handleUpdate = () => {
    if (!editing || !form.title.trim()) return;
    updateCourse(editing.id, form);
    setEditing(null);
    setForm({ title: '', level: '6ème', description: '', content: '' });
    refresh();
  };

  const handleDelete = (id: string) => {
    if (confirm('Supprimer ce cours ?')) {
      deleteCourse(id);
      refresh();
    }
  };

  const startEdit = (course: Course) => {
    setEditing(course);
    setCreating(false);
    setForm({ title: course.title, level: course.level, description: course.description, content: course.content });
  };

  const showForm = creating || editing;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">📚 Gérer les cours</h1>
          <p className="text-gray-500 mt-1">{courses.length} cours publiés</p>
        </div>
        {!showForm && (
          <button
            onClick={() => { setCreating(true); setEditing(null); setForm({ title: '', level: '6ème', description: '', content: '' }); }}
            className="flex items-center gap-2 bg-blue-600 text-white font-bold px-5 py-3 rounded-xl hover:bg-blue-700 transition-all shadow-md"
          >
            <Plus className="w-5 h-5" /> Nouveau cours
          </button>
        )}
      </div>

      {/* Form */}
      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-gray-800">
              {editing ? 'Modifier le cours' : 'Nouveau cours'}
            </h2>
            <button onClick={() => { setCreating(false); setEditing(null); }} className="text-gray-400 hover:text-gray-600">
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Titre *</label>
              <input
                type="text"
                value={form.title}
                onChange={(e) => setForm(f => ({ ...f, title: e.target.value }))}
                placeholder="Ex: Les matériaux"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-300 focus:border-blue-400 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Niveau *</label>
              <select
                value={form.level}
                onChange={(e) => setForm(f => ({ ...f, level: e.target.value }))}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-300 focus:border-blue-400 outline-none"
              >
                <option value="6ème">6ème</option>
                <option value="5ème">5ème</option>
                <option value="4ème">4ème</option>
                <option value="3ème">3ème</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">Description</label>
            <input
              type="text"
              value={form.description}
              onChange={(e) => setForm(f => ({ ...f, description: e.target.value }))}
              placeholder="Résumé du cours..."
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-300 focus:border-blue-400 outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              Contenu du cours * <span className="text-gray-400 font-normal">(utilise # ## ### pour les titres, - pour les listes, ** pour le gras)</span>
            </label>
            <textarea
              value={form.content}
              onChange={(e) => setForm(f => ({ ...f, content: e.target.value }))}
              placeholder="# Mon cours&#10;## Chapitre 1&#10;Le contenu ici..."
              rows={15}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-300 focus:border-blue-400 outline-none font-mono text-sm resize-y"
            />
          </div>

          <div className="flex gap-3 justify-end">
            <button
              onClick={() => { setCreating(false); setEditing(null); }}
              className="px-5 py-2.5 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 transition-all"
            >
              Annuler
            </button>
            <button
              onClick={editing ? handleUpdate : handleCreate}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-700 transition-all shadow-md"
            >
              <Save className="w-4 h-4" />
              {editing ? 'Enregistrer' : 'Publier'}
            </button>
          </div>
        </div>
      )}

      {/* Course List */}
      {courses.length === 0 && !showForm ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-gray-100">
          <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-500">Aucun cours</h3>
          <p className="text-gray-400 text-sm">Commencez par créer votre premier cours</p>
        </div>
      ) : (
        <div className="space-y-3">
          {courses.map((course) => (
            <div key={course.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 flex items-center justify-between hover:shadow-md transition-all">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className={cn(
                    'px-2 py-0.5 rounded-full text-xs font-bold',
                    course.level === '6ème' ? 'bg-emerald-100 text-emerald-700' :
                    course.level === '5ème' ? 'bg-blue-100 text-blue-700' :
                    course.level === '4ème' ? 'bg-purple-100 text-purple-700' :
                    'bg-orange-100 text-orange-700'
                  )}>
                    {course.level}
                  </span>
                  <h3 className="font-bold text-gray-800">{course.title}</h3>
                </div>
                <p className="text-sm text-gray-400">{course.description}</p>
              </div>
              <div className="flex items-center gap-2 ml-4">
                <button
                  onClick={() => startEdit(course)}
                  className="p-2 rounded-lg text-blue-600 hover:bg-blue-50 transition-all"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(course.id)}
                  className="p-2 rounded-lg text-red-500 hover:bg-red-50 transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
