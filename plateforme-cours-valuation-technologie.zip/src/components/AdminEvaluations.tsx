import React, { useState } from 'react';
import { Plus, Edit, Trash2, ClipboardCheck, X, Save, Eye, EyeOff, PlusCircle, MinusCircle } from 'lucide-react';
import { getEvaluations, saveEvaluation, updateEvaluation, deleteEvaluation, deleteResultsByEvaluation, Evaluation, Question } from '../store/dataStore';
import { cn } from '../utils/cn';

const generateId = () => Math.random().toString(36).substring(2, 15) + Date.now().toString(36);

const emptyQuestion = (): Question => ({
  id: generateId(),
  text: '',
  type: 'qcm',
  options: ['', '', '', ''],
  correctAnswer: '',
  points: 2,
});

export const AdminEvaluations: React.FC = () => {
  const [evaluations, setEvaluations] = useState<Evaluation[]>(getEvaluations());
  const [editing, setEditing] = useState<Evaluation | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({
    title: '', level: '6ème', description: '', duration: 20, isActive: true,
    questions: [emptyQuestion()] as Question[],
  });

  const refresh = () => setEvaluations(getEvaluations());

  const handleCreate = () => {
    if (!form.title.trim() || form.questions.length === 0) return;
    saveEvaluation({ ...form, courseId: undefined });
    resetForm();
    refresh();
  };

  const handleUpdate = () => {
    if (!editing) return;
    updateEvaluation(editing.id, form);
    resetForm();
    refresh();
  };

  const handleDelete = (id: string) => {
    if (confirm('Supprimer cette évaluation et tous ses résultats ?')) {
      deleteEvaluation(id);
      deleteResultsByEvaluation(id);
      refresh();
    }
  };

  const toggleActive = (evalItem: Evaluation) => {
    updateEvaluation(evalItem.id, { isActive: !evalItem.isActive });
    refresh();
  };

  const startEdit = (evalItem: Evaluation) => {
    setEditing(evalItem);
    setCreating(false);
    setForm({
      title: evalItem.title,
      level: evalItem.level,
      description: evalItem.description,
      duration: evalItem.duration,
      isActive: evalItem.isActive,
      questions: evalItem.questions,
    });
  };

  const resetForm = () => {
    setCreating(false);
    setEditing(null);
    setForm({ title: '', level: '6ème', description: '', duration: 20, isActive: true, questions: [emptyQuestion()] });
  };

  const updateQuestion = (index: number, updates: Partial<Question>) => {
    setForm(f => {
      const questions = [...f.questions];
      questions[index] = { ...questions[index], ...updates };
      // Reset options when type changes
      if (updates.type === 'truefalse') {
        questions[index].options = undefined;
        questions[index].correctAnswer = '';
      } else if (updates.type === 'qcm' && !questions[index].options) {
        questions[index].options = ['', '', '', ''];
      } else if (updates.type === 'text') {
        questions[index].options = undefined;
      }
      return { ...f, questions };
    });
  };

  const updateOption = (qIndex: number, oIndex: number, value: string) => {
    setForm(f => {
      const questions = [...f.questions];
      const options = [...(questions[qIndex].options || [])];
      options[oIndex] = value;
      questions[qIndex] = { ...questions[qIndex], options };
      return { ...f, questions };
    });
  };

  const addQuestion = () => {
    setForm(f => ({ ...f, questions: [...f.questions, emptyQuestion()] }));
  };

  const removeQuestion = (index: number) => {
    if (form.questions.length <= 1) return;
    setForm(f => ({ ...f, questions: f.questions.filter((_, i) => i !== index) }));
  };

  const showForm = creating || editing;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">✅ Gérer les évaluations</h1>
          <p className="text-gray-500 mt-1">{evaluations.length} évaluation(s)</p>
        </div>
        {!showForm && (
          <button
            onClick={() => { setCreating(true); setEditing(null); setForm({ title: '', level: '6ème', description: '', duration: 20, isActive: true, questions: [emptyQuestion()] }); }}
            className="flex items-center gap-2 bg-green-600 text-white font-bold px-5 py-3 rounded-xl hover:bg-green-700 transition-all shadow-md"
          >
            <Plus className="w-5 h-5" /> Nouvelle évaluation
          </button>
        )}
      </div>

      {/* Form */}
      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-gray-800">
              {editing ? 'Modifier l\'évaluation' : 'Nouvelle évaluation'}
            </h2>
            <button onClick={resetForm} className="text-gray-400 hover:text-gray-600">
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* General info */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-semibold text-gray-700 mb-1">Titre *</label>
              <input
                type="text"
                value={form.title}
                onChange={(e) => setForm(f => ({ ...f, title: e.target.value }))}
                placeholder="Ex: Évaluation sur les matériaux"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-300 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Niveau</label>
              <select
                value={form.level}
                onChange={(e) => setForm(f => ({ ...f, level: e.target.value }))}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-300 outline-none"
              >
                <option value="6ème">6ème</option>
                <option value="5ème">5ème</option>
                <option value="4ème">4ème</option>
                <option value="3ème">3ème</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Description</label>
              <input
                type="text"
                value={form.description}
                onChange={(e) => setForm(f => ({ ...f, description: e.target.value }))}
                placeholder="Description de l'évaluation..."
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-300 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Durée (minutes)</label>
              <input
                type="number"
                value={form.duration}
                onChange={(e) => setForm(f => ({ ...f, duration: parseInt(e.target.value) || 15 }))}
                min={5}
                max={120}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-300 outline-none"
              />
            </div>
          </div>

          {/* Questions */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-gray-800 border-b border-gray-100 pb-2">
              Questions ({form.questions.length})
            </h3>

            {form.questions.map((question, qIndex) => (
              <div key={question.id} className="bg-gray-50 rounded-xl p-5 space-y-3 border border-gray-100">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-blue-600">Question {qIndex + 1}</span>
                  <button onClick={() => removeQuestion(qIndex)} className="text-red-400 hover:text-red-600">
                    <MinusCircle className="w-5 h-5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="md:col-span-2">
                    <input
                      type="text"
                      value={question.text}
                      onChange={(e) => updateQuestion(qIndex, { text: e.target.value })}
                      placeholder="Énoncé de la question..."
                      className="w-full px-4 py-2.5 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-300 outline-none text-sm"
                    />
                  </div>
                  <div className="flex gap-2">
                    <select
                      value={question.type}
                      onChange={(e) => updateQuestion(qIndex, { type: e.target.value as 'qcm' | 'text' | 'truefalse' })}
                      className="flex-1 px-3 py-2.5 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-300 outline-none text-sm"
                    >
                      <option value="qcm">QCM</option>
                      <option value="truefalse">Vrai/Faux</option>
                      <option value="text">Texte libre</option>
                    </select>
                    <input
                      type="number"
                      value={question.points}
                      onChange={(e) => updateQuestion(qIndex, { points: parseInt(e.target.value) || 1 })}
                      min={1}
                      max={10}
                      className="w-16 px-2 py-2.5 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-300 outline-none text-sm text-center"
                      title="Points"
                    />
                  </div>
                </div>

                {question.type === 'qcm' && question.options && (
                  <div className="space-y-2">
                    <p className="text-xs text-gray-500 font-medium">Options (cliquez sur la bonne réponse) :</p>
                    {question.options.map((opt, oIndex) => (
                      <div key={oIndex} className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => updateQuestion(qIndex, { correctAnswer: opt })}
                          className={cn(
                            'w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border-2 transition-all flex-shrink-0',
                            question.correctAnswer === opt && opt !== ''
                              ? 'bg-green-500 border-green-500 text-white'
                              : 'border-gray-300 text-gray-400 hover:border-green-400'
                          )}
                        >
                          {String.fromCharCode(65 + oIndex)}
                        </button>
                        <input
                          type="text"
                          value={opt}
                          onChange={(e) => {
                            const oldVal = opt;
                            updateOption(qIndex, oIndex, e.target.value);
                            if (question.correctAnswer === oldVal) {
                              updateQuestion(qIndex, { correctAnswer: e.target.value });
                            }
                          }}
                          placeholder={`Option ${String.fromCharCode(65 + oIndex)}`}
                          className="flex-1 px-3 py-2 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-300 outline-none text-sm"
                        />
                      </div>
                    ))}
                  </div>
                )}

                {question.type === 'truefalse' && (
                  <div className="flex gap-3">
                    <p className="text-xs text-gray-500 font-medium self-center">Bonne réponse :</p>
                    {['vrai', 'faux'].map((val) => (
                      <button
                        key={val}
                        type="button"
                        onClick={() => updateQuestion(qIndex, { correctAnswer: val })}
                        className={cn(
                          'px-4 py-2 rounded-lg font-medium text-sm border-2 transition-all',
                          question.correctAnswer === val
                            ? val === 'vrai' ? 'bg-green-500 border-green-500 text-white' : 'bg-red-500 border-red-500 text-white'
                            : 'border-gray-200 text-gray-500 hover:border-gray-400'
                        )}
                      >
                        {val === 'vrai' ? '✅ Vrai' : '❌ Faux'}
                      </button>
                    ))}
                  </div>
                )}

                {question.type === 'text' && (
                  <div>
                    <p className="text-xs text-gray-500 font-medium mb-1">Mots-clés attendus (séparés par des espaces) :</p>
                    <input
                      type="text"
                      value={question.correctAnswer}
                      onChange={(e) => updateQuestion(qIndex, { correctAnswer: e.target.value })}
                      placeholder="Ex: conducteur résistant recyclable"
                      className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:ring-2 focus:ring-blue-300 outline-none text-sm"
                    />
                  </div>
                )}
              </div>
            ))}

            <button
              onClick={addQuestion}
              className="flex items-center gap-2 w-full justify-center py-3 rounded-xl border-2 border-dashed border-gray-300 text-gray-500 hover:border-blue-400 hover:text-blue-600 transition-all"
            >
              <PlusCircle className="w-5 h-5" /> Ajouter une question
            </button>
          </div>

          <div className="flex gap-3 justify-end pt-4 border-t border-gray-100">
            <button onClick={resetForm} className="px-5 py-2.5 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50">
              Annuler
            </button>
            <button
              onClick={editing ? handleUpdate : handleCreate}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-green-600 text-white font-bold hover:bg-green-700 transition-all shadow-md"
            >
              <Save className="w-4 h-4" />
              {editing ? 'Enregistrer' : 'Créer l\'évaluation'}
            </button>
          </div>
        </div>
      )}

      {/* Evaluation List */}
      {evaluations.length === 0 && !showForm ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-gray-100">
          <ClipboardCheck className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-500">Aucune évaluation</h3>
          <p className="text-gray-400 text-sm">Créez votre première évaluation</p>
        </div>
      ) : (
        <div className="space-y-3">
          {evaluations.map((evalItem) => (
            <div key={evalItem.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 flex items-center justify-between hover:shadow-md transition-all">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className={cn(
                    'px-2 py-0.5 rounded-full text-xs font-bold',
                    evalItem.level === '6ème' ? 'bg-emerald-100 text-emerald-700' :
                    evalItem.level === '5ème' ? 'bg-blue-100 text-blue-700' :
                    evalItem.level === '4ème' ? 'bg-purple-100 text-purple-700' :
                    'bg-orange-100 text-orange-700'
                  )}>
                    {evalItem.level}
                  </span>
                  <h3 className="font-bold text-gray-800">{evalItem.title}</h3>
                  <span className={cn(
                    'px-2 py-0.5 rounded-full text-xs font-bold',
                    evalItem.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
                  )}>
                    {evalItem.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>
                <p className="text-sm text-gray-400">
                  {evalItem.questions.length} questions • {evalItem.questions.reduce((s, q) => s + q.points, 0)} pts • {evalItem.duration} min
                </p>
              </div>
              <div className="flex items-center gap-2 ml-4">
                <button
                  onClick={() => toggleActive(evalItem)}
                  className={cn('p-2 rounded-lg transition-all', evalItem.isActive ? 'text-green-600 hover:bg-green-50' : 'text-gray-400 hover:bg-gray-50')}
                  title={evalItem.isActive ? 'Désactiver' : 'Activer'}
                >
                  {evalItem.isActive ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                </button>
                <button onClick={() => startEdit(evalItem)} className="p-2 rounded-lg text-blue-600 hover:bg-blue-50">
                  <Edit className="w-4 h-4" />
                </button>
                <button onClick={() => handleDelete(evalItem.id)} className="p-2 rounded-lg text-red-500 hover:bg-red-50">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
