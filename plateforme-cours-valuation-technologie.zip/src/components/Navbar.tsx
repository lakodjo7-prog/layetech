import React from 'react';
import { BookOpen, ClipboardCheck, BarChart3, Settings, Home, GraduationCap, LogOut } from 'lucide-react';
import { cn } from '../utils/cn';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  isAdmin: boolean;
  onLogout?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPage, onNavigate, isAdmin, onLogout }) => {
  const studentLinks = [
    { id: 'home', label: 'Accueil', icon: Home },
    { id: 'courses', label: 'Cours', icon: BookOpen },
    { id: 'evaluations', label: 'Évaluations', icon: ClipboardCheck },
  ];

  const adminLinks = [
    { id: 'admin-dashboard', label: 'Tableau de bord', icon: Home },
    { id: 'admin-courses', label: 'Gérer les cours', icon: BookOpen },
    { id: 'admin-evaluations', label: 'Gérer les évaluations', icon: ClipboardCheck },
    { id: 'admin-results', label: 'Résultats', icon: BarChart3 },
    { id: 'admin-settings', label: 'Paramètres', icon: Settings },
  ];

  const links = isAdmin ? adminLinks : studentLinks;

  return (
    <nav className="bg-gradient-to-r from-blue-700 to-indigo-800 text-white shadow-xl">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate(isAdmin ? 'admin-dashboard' : 'home')}>
            <GraduationCap className="w-8 h-8 text-yellow-300" />
            <div>
              <h1 className="text-lg font-bold leading-tight">LayeTech</h1>
              <p className="text-xs text-blue-200">{isAdmin ? 'Espace Professeur' : 'Espace Élève'}</p>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-1">
            {links.map((link) => (
              <button
                key={link.id}
                onClick={() => onNavigate(link.id)}
                className={cn(
                  'flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all',
                  currentPage === link.id
                    ? 'bg-white/20 text-white shadow-inner'
                    : 'text-blue-100 hover:bg-white/10 hover:text-white'
                )}
              >
                <link.icon className="w-4 h-4" />
                {link.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            {!isAdmin && (
              <button
                onClick={() => onNavigate('admin-login')}
                className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm bg-white/10 hover:bg-white/20 transition-all"
              >
                <Settings className="w-4 h-4" />
                <span className="hidden sm:inline">Espace Prof</span>
              </button>
            )}
            {isAdmin && onLogout && (
              <button
                onClick={onLogout}
                className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm bg-red-500/20 hover:bg-red-500/40 transition-all"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Déconnexion</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile navigation */}
        <div className="md:hidden flex overflow-x-auto gap-1 pb-3 -mx-2 px-2">
          {links.map((link) => (
            <button
              key={link.id}
              onClick={() => onNavigate(link.id)}
              className={cn(
                'flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all',
                currentPage === link.id
                  ? 'bg-white/20 text-white'
                  : 'text-blue-200 hover:bg-white/10'
              )}
            >
              <link.icon className="w-3.5 h-3.5" />
              {link.label}
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
};
