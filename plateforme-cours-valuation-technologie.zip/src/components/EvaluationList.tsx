import React, { useState } from 'react';
import { ClipboardCheck, Clock, Tag, AlertCircle, CheckCircle } from 'lucide-react';
import { getEvaluations, Evaluation } from '../store/dataStore';
import { TakeEvaluation } from './TakeEvaluation';
import { cn } from '../utils/cn';

export const EvaluationList: React.FC = () => {
  const [evaluations] = useState<Evaluation[]>(getEvaluations().filter(e => e.isActive));
  const [selectedEval, setSelectedEval] = useState<Evaluation | null>(null);
  const [completedEval, setCompletedEval] = useState<{ score: number; max: number; percentage: number } | null>(null);
  const [filterLevel, setFilterLevel] = useState('');

  const levels = [...new Set(evaluations.map(e => e.level))];

  const filtered = evaluations.filter(e => {
    if (filterLevel && e.level !== filterLevel) return false;
    return true;
  });

  const levelColors: Record<string, string> = {
    '6ème': 'bg-emerald-100 text-emerald-700',
    '5ème': 'bg-blue-100 text-blue-700',
    '4ème': 'bg-purple-100 text-purple-700',
    '3ème': 'bg-orange-100 text-orange-700',
  };

  if (selectedEval && !completedEval) {
    return (
      <TakeEvaluation
        evaluation={selectedEval}
        onComplete={(result) => {
          setCompletedEval({ score: result.totalScore, max: result.maxScore, percentage: result.percentage });
        }}
        onBack={() => setSelectedEval(null)}
      />
    );
  }

  if (completedEval) {
    return (
      <div className="max-w-lg mx-auto text-center space-y-6 py-12">
        <div className={cn(
          'w-24 h-24 rounded-full flex items-center justify-center mx-auto',
          completedEval.percentage >= 50 ? 'bg-green-100' : 'bg-red-100'
        )}>
          {completedEval.percentage >= 50 ? (
            <CheckCircle className="w-12 h-12 text-green-600" />
          ) : (
            <AlertCircle className="w-12 h-12 text-red-600" />
          )}
        </div>
        <h2 className="text-3xl font-bold text-gray-800">Évaluation terminée !</h2>
        <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100">
          <p className="text-5xl font-extrabold text-blue-600 mb-2">{completedEval.score} / {completedEval.max}</p>
          <p className="text-lg text-gray-500">Soit {completedEval.percentage.toFixed(0)}% de réussite</p>
          <div className="mt-4 bg-gray-100 rounded-full h-4 overflow-hidden">
            <div
              className={cn(
                'h-full rounded-full transition-all',
                completedEval.percentage >= 75 ? 'bg-green-500' :
                completedEval.percentage >= 50 ? 'bg-yellow-500' : 'bg-red-500'
              )}
              style={{ width: `${completedEval.percentage}%` }}
            ></div>
          </div>
          <p className="mt-4 text-sm text-gray-400">
            {completedEval.percentage >= 75 ? 'Excellent travail ! 🎉' :
             completedEval.percentage >= 50 ? 'Bien, continue tes efforts ! 💪' :
             'Révise bien le cours et réessaie ! 📖'}
          </p>
        </div>
        <button
          onClick={() => { setSelectedEval(null); setCompletedEval(null); }}
          className="bg-blue-600 text-white font-bold px-8 py-3 rounded-xl hover:bg-blue-700 transition-all"
        >
          Retour aux évaluations
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-800">✅ Évaluations</h1>
        <p className="text-gray-500 mt-1">Passe tes évaluations en ligne et vérifie tes connaissances</p>
      </div>

      <div className="flex gap-2 flex-wrap">
        <button
          onClick={() => setFilterLevel('')}
          className={cn(
            'px-4 py-2 rounded-xl text-sm font-medium transition-all',
            !filterLevel ? 'bg-blue-600 text-white shadow-md' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          )}
        >
          Tous les niveaux
        </button>
        {levels.map((level) => (
          <button
            key={level}
            onClick={() => setFilterLevel(level)}
            className={cn(
              'px-4 py-2 rounded-xl text-sm font-medium transition-all',
              filterLevel === level ? 'bg-blue-600 text-white shadow-md' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            )}
          >
            {level}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-gray-100">
          <ClipboardCheck className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-500">Aucune évaluation disponible</h3>
          <p className="text-gray-400 text-sm">Les évaluations apparaîtront ici quand ton professeur les activera.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((evaluation) => (
            <div
              key={evaluation.id}
              className="bg-white rounded-2xl shadow-sm border border-gray-100 hover:shadow-lg transition-all group"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <span className={cn('px-3 py-1 rounded-full text-xs font-bold', levelColors[evaluation.level] || 'bg-gray-100 text-gray-600')}>
                    <Tag className="w-3 h-3 inline mr-1" />
                    {evaluation.level}
                  </span>
                  <span className="flex items-center gap-1 text-sm text-gray-400">
                    <Clock className="w-4 h-4" />
                    {evaluation.duration} min
                  </span>
                </div>
                <h3 className="text-lg font-bold text-gray-800 mb-2">{evaluation.title}</h3>
                <p className="text-gray-500 text-sm mb-3">{evaluation.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-400">
                    {evaluation.questions.length} question{evaluation.questions.length > 1 ? 's' : ''} • {evaluation.questions.reduce((sum, q) => sum + q.points, 0)} points
                  </span>
                  <button
                    onClick={() => setSelectedEval(evaluation)}
                    className="bg-blue-600 text-white font-bold px-5 py-2 rounded-xl hover:bg-blue-700 transition-all text-sm shadow-md hover:shadow-lg"
                  >
                    Commencer →
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
