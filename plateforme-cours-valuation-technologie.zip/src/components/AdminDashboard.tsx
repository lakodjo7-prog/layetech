import React from 'react';
import { BookOpen, ClipboardCheck, Users, TrendingUp, BarChart3 } from 'lucide-react';
import { getCourses, getEvaluations, getResults } from '../store/dataStore';

interface AdminDashboardProps {
  onNavigate: (page: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigate }) => {
  const courses = getCourses();
  const evaluations = getEvaluations();
  const results = getResults();

  const avgScore = results.length > 0
    ? results.reduce((sum, r) => sum + r.percentage, 0) / results.length
    : 0;

  const recentResults = [...results].sort((a, b) => 
    new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime()
  ).slice(0, 5);

  const stats = [
    { label: 'Cours publiés', value: courses.length, icon: BookOpen, color: 'bg-blue-100 text-blue-600', bgCard: 'from-blue-50 to-blue-100/50' },
    { label: 'Évaluations', value: evaluations.length, icon: ClipboardCheck, color: 'bg-green-100 text-green-600', bgCard: 'from-green-50 to-green-100/50' },
    { label: 'Copies rendues', value: results.length, icon: Users, color: 'bg-purple-100 text-purple-600', bgCard: 'from-purple-50 to-purple-100/50' },
    { label: 'Moyenne générale', value: `${avgScore.toFixed(1)}%`, icon: TrendingUp, color: 'bg-orange-100 text-orange-600', bgCard: 'from-orange-50 to-orange-100/50' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-800">📊 Tableau de bord</h1>
        <p className="text-gray-500 mt-1">Vue d'ensemble de votre espace pédagogique</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <div key={stat.label} className={`bg-gradient-to-br ${stat.bgCard} rounded-2xl p-6 border border-white shadow-sm`}>
            <div className={`w-12 h-12 ${stat.color} rounded-xl flex items-center justify-center mb-3`}>
              <stat.icon className="w-6 h-6" />
            </div>
            <p className="text-3xl font-extrabold text-gray-800">{stat.value}</p>
            <p className="text-sm text-gray-500 mt-1">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button
          onClick={() => onNavigate('admin-courses')}
          className="bg-white rounded-2xl p-6 border border-gray-100 hover:shadow-lg transition-all text-left group"
        >
          <BookOpen className="w-8 h-8 text-blue-600 mb-3 group-hover:scale-110 transition-transform" />
          <h3 className="font-bold text-gray-800">Ajouter un cours</h3>
          <p className="text-sm text-gray-500 mt-1">Créer ou modifier vos cours</p>
        </button>
        <button
          onClick={() => onNavigate('admin-evaluations')}
          className="bg-white rounded-2xl p-6 border border-gray-100 hover:shadow-lg transition-all text-left group"
        >
          <ClipboardCheck className="w-8 h-8 text-green-600 mb-3 group-hover:scale-110 transition-transform" />
          <h3 className="font-bold text-gray-800">Créer une évaluation</h3>
          <p className="text-sm text-gray-500 mt-1">Préparer un QCM ou quiz</p>
        </button>
        <button
          onClick={() => onNavigate('admin-results')}
          className="bg-white rounded-2xl p-6 border border-gray-100 hover:shadow-lg transition-all text-left group"
        >
          <BarChart3 className="w-8 h-8 text-purple-600 mb-3 group-hover:scale-110 transition-transform" />
          <h3 className="font-bold text-gray-800">Voir les résultats</h3>
          <p className="text-sm text-gray-500 mt-1">Consulter les copies rendues</p>
        </button>
      </div>

      {/* Recent Results */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm">
        <div className="p-6 border-b border-gray-100">
          <h2 className="text-lg font-bold text-gray-800">📋 Dernières copies rendues</h2>
        </div>
        {recentResults.length === 0 ? (
          <div className="p-8 text-center text-gray-400">
            <Users className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <p>Aucune copie rendue pour le moment</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-50">
            {recentResults.map((result) => {
              const evaluation = evaluations.find(e => e.id === result.evaluationId);
              return (
                <div key={result.id} className="p-4 px-6 flex items-center justify-between hover:bg-gray-50 transition-all">
                  <div>
                    <p className="font-semibold text-gray-800">{result.studentName}</p>
                    <p className="text-sm text-gray-400">{result.studentClass} • {evaluation?.title || 'Évaluation supprimée'}</p>
                  </div>
                  <div className="text-right">
                    <p className={`font-bold text-lg ${result.percentage >= 50 ? 'text-green-600' : 'text-red-500'}`}>
                      {result.totalScore}/{result.maxScore}
                    </p>
                    <p className="text-xs text-gray-400">
                      {new Date(result.submittedAt).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
