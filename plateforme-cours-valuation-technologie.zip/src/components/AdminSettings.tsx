import React, { useState } from 'react';
import { Lock, Save, CheckCircle, AlertCircle, Database, Trash2 } from 'lucide-react';
import { getAdminPassword, setAdminPassword } from '../store/dataStore';

export const AdminSettings: React.FC = () => {
  const [currentPwd, setCurrentPwd] = useState('');
  const [newPwd, setNewPwd] = useState('');
  const [confirmPwd, setConfirmPwd] = useState('');
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleChangePwd = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (currentPwd !== getAdminPassword()) {
      setMessage({ type: 'error', text: 'Mot de passe actuel incorrect' });
      return;
    }
    if (newPwd.length < 4) {
      setMessage({ type: 'error', text: 'Le nouveau mot de passe doit faire au moins 4 caractères' });
      return;
    }
    if (newPwd !== confirmPwd) {
      setMessage({ type: 'error', text: 'Les mots de passe ne correspondent pas' });
      return;
    }

    setAdminPassword(newPwd);
    setCurrentPwd('');
    setNewPwd('');
    setConfirmPwd('');
    setMessage({ type: 'success', text: 'Mot de passe modifié avec succès !' });
    setTimeout(() => setMessage(null), 3000);
  };

  const handleClearData = (key: string, label: string) => {
    if (confirm(`Êtes-vous sûr de vouloir supprimer ${label} ? Cette action est irréversible.`)) {
      localStorage.removeItem(key);
      setMessage({ type: 'success', text: `${label} supprimé(s) avec succès` });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-800">⚙️ Paramètres</h1>
        <p className="text-gray-500 mt-1">Gérez votre espace professeur</p>
      </div>

      {message && (
        <div className={`flex items-center gap-2 p-4 rounded-xl ${message.type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
          {message.type === 'success' ? <CheckCircle className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
          {message.text}
        </div>
      )}

      {/* Change Password */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
            <Lock className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-gray-800">Changer le mot de passe</h2>
            <p className="text-sm text-gray-400">Sécurisez votre espace professeur</p>
          </div>
        </div>

        <form onSubmit={handleChangePwd} className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">Mot de passe actuel</label>
            <input
              type="password"
              value={currentPwd}
              onChange={(e) => setCurrentPwd(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-300 outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">Nouveau mot de passe</label>
            <input
              type="password"
              value={newPwd}
              onChange={(e) => setNewPwd(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-300 outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">Confirmer le nouveau mot de passe</label>
            <input
              type="password"
              value={confirmPwd}
              onChange={(e) => setConfirmPwd(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-blue-300 outline-none"
            />
          </div>
          <button
            type="submit"
            className="flex items-center gap-2 bg-blue-600 text-white font-bold px-6 py-3 rounded-xl hover:bg-blue-700 transition-all shadow-md"
          >
            <Save className="w-4 h-4" /> Modifier le mot de passe
          </button>
        </form>
      </div>

      {/* Data Management */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-red-100 rounded-xl flex items-center justify-center">
            <Database className="w-5 h-5 text-red-600" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-gray-800">Gestion des données</h2>
            <p className="text-sm text-gray-400">Attention, les suppressions sont irréversibles</p>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
            <div>
              <p className="font-semibold text-gray-700">Résultats des élèves</p>
              <p className="text-sm text-gray-400">Supprimer toutes les copies rendues</p>
            </div>
            <button
              onClick={() => handleClearData('techno_results', 'tous les résultats')}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-red-100 text-red-700 hover:bg-red-200 transition-all text-sm font-medium"
            >
              <Trash2 className="w-4 h-4" /> Supprimer
            </button>
          </div>
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
            <div>
              <p className="font-semibold text-gray-700">Toutes les évaluations</p>
              <p className="text-sm text-gray-400">Supprimer toutes les évaluations et leurs résultats</p>
            </div>
            <button
              onClick={() => {
                handleClearData('techno_evaluations', 'toutes les évaluations');
                localStorage.removeItem('techno_results');
              }}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-red-100 text-red-700 hover:bg-red-200 transition-all text-sm font-medium"
            >
              <Trash2 className="w-4 h-4" /> Supprimer
            </button>
          </div>
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
            <div>
              <p className="font-semibold text-gray-700">Tous les cours</p>
              <p className="text-sm text-gray-400">Supprimer tous les cours publiés</p>
            </div>
            <button
              onClick={() => handleClearData('techno_courses', 'tous les cours')}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-red-100 text-red-700 hover:bg-red-200 transition-all text-sm font-medium"
            >
              <Trash2 className="w-4 h-4" /> Supprimer
            </button>
          </div>
        </div>
      </div>

      {/* Info */}
      <div className="bg-blue-50 rounded-2xl p-6 border border-blue-100">
        <h3 className="font-bold text-blue-800 mb-2">💡 Informations</h3>
        <ul className="text-sm text-blue-700 space-y-1">
          <li>• Les données sont stockées dans le navigateur (localStorage)</li>
          <li>• Pour accéder aux résultats depuis chez vous, utilisez le même navigateur sur le même appareil</li>
          <li>• Pensez à exporter régulièrement les résultats en CSV pour les sauvegarder</li>
          <li>• Le mot de passe par défaut est : <code className="bg-blue-100 px-1 rounded">prof2024</code></li>
        </ul>
      </div>
    </div>
  );
};
